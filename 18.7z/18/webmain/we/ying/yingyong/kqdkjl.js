yy.onclickmenu=function(a){
	if(a.url=='add_kqdkjl'){
		js.location('?d=we&m=ying&a=location');
		return;
	}
	return true;
}
