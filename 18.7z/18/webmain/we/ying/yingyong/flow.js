yy.onclickmenu=function(d){
	if(d.url=='moreapply'){
		js.location('?d=we&m=flow&a=apply');
	}else{
		return true;
	}
}