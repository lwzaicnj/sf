<?php
class flow_officiaClassModel extends flowModel
{

	protected function flowdatalog($arr)
	{
		
		$arr['title'] 		= '';

		return $arr;
	}
}