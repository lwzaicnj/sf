<?php 
/**
*	桌面首页项(通知公告)
*/
defined('HOST') or die ('not access');

?>

<div class="panel panel-default">
  <div class="panel-heading">
	<div class="panel-title">微信办公</div>
  </div>
  <div class="panel-body">
		<table><tr valign="top">
		<td align="center"><img src="images/wxqcode.jpg" height="140">
		<div style="color:#888888">扫一扫体验微信办公</div></td>
		<td>
			<div style="line-height:26px;padding:5px;">
			<b>企业微信和微信企业号办公</b><br>&nbsp; &nbsp; 结合了信呼上系统，单据待办推送提醒到个人微信和企业微信上，<a href="<?=URLY?>view_weixin.html" target="_blank">[微信企业号]</a>，<a href="<?=URLY?>view_weixinqy.html" target="_blank">[企业微信]</a>。<br>
			1、申请微信企业号体验，去<a href="<?=URLY?>view_weixinty.html" target="_blank">[申请]</a>。<br>
			2、扫一扫验证帐号即可使用。<br>
			3、可到【系统→系统工具→升级系统】下安装，有问题？<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=290802026&site=qq&menu=yes"><img border="0" align="absmiddle" src="<?=URLY?>images/qquser.png" height="22" title="在线交流"/></a>
			</div>
		</td>
		</tr></table>
	
	
  </div>
</div>