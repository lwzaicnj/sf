<?php
class bookClassAction extends Action
{
	
}