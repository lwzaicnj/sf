<?php
class workClassAction extends runtAction
{
	public function todoAction()
	{
		
		echo 'success';
	}
}